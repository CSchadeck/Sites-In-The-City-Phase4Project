import React, { useState } from "react";
import Movies from "./Movies";


function View() {
 

  return (
    <div>
      <Movies/>
    </div>
  );
}

export default View;

